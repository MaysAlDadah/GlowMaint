<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "final";

$conn = mysqli_connect($host,$user,$pass,$db);